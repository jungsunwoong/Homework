<template>
  <div>
    <Calc />
  </div>
</template>
<script>
import Calc from './components/Calc.vue'
// import Calc from './components/Calc2.vue'
// import Calc from './components/Calc3.vue'
// import Calc from './components/Calc4.vue'
// import Calc from './components/Calc5.vue'
export default {
  name: 'App',
  components: { Calc },
}
</script>
