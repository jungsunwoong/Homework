import { createApp } from 'vue';
import App from './App.vue';
//import App from './App2.vue'

import './assets/main.css';

createApp(App).mount('#app');
